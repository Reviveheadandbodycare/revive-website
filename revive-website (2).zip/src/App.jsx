import React from 'react';
import './styles/index.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="p-4 text-center text-xl font-semibold">Revive Head & Body Care</header>
      <main className="p-4">
        <h2 className="text-lg font-medium mb-2">Relax · Refresh · Revive</h2>
        <p>Welcome to your scalp therapy space.</p>
      </main>
    </div>
  );
}

export default App;